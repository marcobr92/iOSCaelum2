//: Playground - noun: a place where people can play

// Constantes Vs Variaveis
let num1: Int = 10
let num2: Double = 5.2
var soma = Double(num1) + num2

// String
var nome: String = "Marco"

// Concatenação
nome += " Beraldi"

// Interpolação
let nome1 = "Steve Jobs"
let idade = 61
// Se Steve Jobs estivesse vivo, teria 61 anos
let status = "Se \(nome1) estivesse vivo, teria \(idade) anos"
// ou
print("Se \(nome1) estivesse vivo, teria \(idade) anos")
print(status)

/*
 Tuplas
 */
let httpCode = 404
let httpMsg = "Not found"
print("Erro \(httpCode) - Msg: \(httpMsg)")

let http404Error = (404, "Not found")

// Como exibir as informações da tupla?
//1. Por decomposição
let (statusCode, statusmessage) = http404Error

//2. Pelo indice
print("O codigo de erro é: \(http404Error.0)")
print("A mensagem de erro é: \(http404Error.1)")

// Comparações em Swift
let valor1 = 10
let valor2 = 20
if valor1 == valor2{
    print("Valores iguais")
} else {
    print("Valores diferentes")
}
